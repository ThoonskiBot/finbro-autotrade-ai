# Mock FINBRO content for tools/alpha_audit_engine.py
