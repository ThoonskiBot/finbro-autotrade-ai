# Mock FINBRO content for tools/reward_logger.py
